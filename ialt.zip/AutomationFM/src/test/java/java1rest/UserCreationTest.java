package java1rest;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;

public class UserCreationTest
{
    public static  String mail;
    List<String> PDFstrings = new ArrayList<>();
    List<String> CLFstrings = new ArrayList<>();
    List<String> ALTstrings = new ArrayList<>();
    Response response;




    @Test(invocationCount = 5, threadPoolSize = 20,priority = 1)
    public void testPdfUpload()
{

    for(int i=1;i<=20;i++) {


        RestAssured.useRelaxedHTTPSValidation();
        // Set the base URL for the API
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

        //String accessToken = "YOUR_ACCESS_TOKEN"; // Replace with your actual token

        String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NWIyNTU5YTAxN2E0ZjQ2YmJjOTY4NjkiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjYyMTAwMjEsImV4cCI6MTcyNjIxMzYyMSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.mEGvuEF_x55uhrh2Hw8u_5_SlnDY3kBisCpWi50n9-YsX-CD2DaFiFQ0B_CEo-VEz9y33XIKt_DnGayC6bhKTboMcJYSJnx8g5KuBlrLHZOGnDP_iAOuwGTolky4CLFRerpu4okH_NM4Aqjj6s4tmpkfvURWqhAQNtFTyR5Mej-tntMl137uCFD4JEWPOrOMBU2xaNH65J5_1YNBpY97J5Sxz3DjBNpmjKIHhB4XyuTG0YEyixboX2jGFBIWBjaoTw9t8HFe6R2gFPvIVA6UZbRFj1JOUAm1Lh1BWgBbZKZ5c5AcG7aDw3ipHpLJaEdQo988VCPsSEkOAkB41xQHLA";

        // Initialize list to store strings
       // List<String> strings = new ArrayList<>();

        // Specify the request
        Response response = given().log().all()
                .header("Authorization", "Bearer " + accessToken)  // Correctly formatted Authorization header
                .contentType("multipart/form-data")  // Set Content-Type to multipart/form-data
                .multiPart("files", new File("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\data\\z.pdf"), "application/pdf")  // Attach PDF file as multipart with Content-Type as application/pdf
                .when()
                .post("/v1/ialtimage/ImagePDFExtraction")  // Ensure the endpoint is specified correctly; here it uses the baseURI
                .then().log().all()
                .statusCode(201)  // Expecting HTTP status code 201 Created
                .extract()
                .response();

        // Optionally, extract the response ID or other data
        String userId = response.jsonPath().getString("_id");
        System.out.println("PDFstrings ID: " + userId);

        PDFstrings.add(userId);
        PDFstrings.add("Next--");
       // System.out.println(PDFstrings);
        System.out.println(PDFstrings.size());

    }
}


@Test(invocationCount = 5, threadPoolSize = 20,priority = 2)

public void getImageClassificationgroup()
{

        for(int i=1;i<=1;i++) {


            RestAssured.useRelaxedHTTPSValidation();

            RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

            String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NWIyNTU5YTAxN2E0ZjQ2YmJjOTY4NjkiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjYyMTAwMjEsImV4cCI6MTcyNjIxMzYyMSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.mEGvuEF_x55uhrh2Hw8u_5_SlnDY3kBisCpWi50n9-YsX-CD2DaFiFQ0B_CEo-VEz9y33XIKt_DnGayC6bhKTboMcJYSJnx8g5KuBlrLHZOGnDP_iAOuwGTolky4CLFRerpu4okH_NM4Aqjj6s4tmpkfvURWqhAQNtFTyR5Mej-tntMl137uCFD4JEWPOrOMBU2xaNH65J5_1YNBpY97J5Sxz3DjBNpmjKIHhB4XyuTG0YEyixboX2jGFBIWBjaoTw9t8HFe6R2gFPvIVA6UZbRFj1JOUAm1Lh1BWgBbZKZ5c5AcG7aDw3ipHpLJaEdQo988VCPsSEkOAkB41xQHLA";


            for (String ImgID : PDFstrings) {
                System.out.println(ImgID);

                // Initialize list to store strings
                // List<String> strings = new ArrayList<>();
                String ReqBody = "[{\n" +
                        "    \"id\":\"" + ImgID + "\"\n" +
                        "}]\n";

                // Specify the request
                 response = given().log().all()
                        .contentType("application/json")
                        .header("Authorization", "Bearer " + accessToken)  // Correctly formatted Authorization header
                        // .contentType("multipart/form-data")
                        .body(ReqBody)// Set Content-Type to multipart/form-data
                        //.multiPart("files", new File("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\data\\z.pdf"), "application/pdf")  // Attach PDF file as multipart with Content-Type as application/pdf
                        .when()
                        .post("/v1/ialtservice/getImageClassificationgroup")  // Ensure the endpoint is specified correctly; here it uses the baseURI
                        .then().log().all()
                        .statusCode(200)  // Expecting HTTP status code 201 Created
                        .extract()
                        .response();

            }

            // Optionally, extract the response ID or other data
            String ClarificationID = response.jsonPath().getString("_id");
            System.out.println("CLFstrings ID: " + ClarificationID);

            CLFstrings.add(ClarificationID);
            CLFstrings.add("Next--");
            System.out.println(CLFstrings);
            System.out.println(CLFstrings.size());

        }
    }


    @Test(invocationCount = 5, threadPoolSize = 20,priority = 3)

    public void generateAltTextNewVersion()
    {

        for(int i=1;i<=1;i++) {


            RestAssured.useRelaxedHTTPSValidation();

            RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

            String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NWIyNTU5YTAxN2E0ZjQ2YmJjOTY4NjkiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjYyMTAwMjEsImV4cCI6MTcyNjIxMzYyMSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.mEGvuEF_x55uhrh2Hw8u_5_SlnDY3kBisCpWi50n9-YsX-CD2DaFiFQ0B_CEo-VEz9y33XIKt_DnGayC6bhKTboMcJYSJnx8g5KuBlrLHZOGnDP_iAOuwGTolky4CLFRerpu4okH_NM4Aqjj6s4tmpkfvURWqhAQNtFTyR5Mej-tntMl137uCFD4JEWPOrOMBU2xaNH65J5_1YNBpY97J5Sxz3DjBNpmjKIHhB4XyuTG0YEyixboX2jGFBIWBjaoTw9t8HFe6R2gFPvIVA6UZbRFj1JOUAm1Lh1BWgBbZKZ5c5AcG7aDw3ipHpLJaEdQo988VCPsSEkOAkB41xQHLA";
            for (String ImgID : CLFstrings) {
                System.out.println(ImgID);
                // Initialize list to store strings
                List<String> strings = new ArrayList<>();
                String ReqBody = "[\n" +
                        "  {\n" +
                        "    \"id\": \"6673d71a9c7cc144c47bdefa\",\n" +
                        "    \"duId\": \"94\",\n" +
                        "    \"customerId\": \"14\",\n" +
                        "    \"wfId\": 38,\n" +
                        "    \"userId\": \"IS8433\",\n" +
                        "    \"bookid\": 157,\n" +
                        "    \"workorderId\": \"2971\",\n" +
                        "    \"serviceId\": \"1\",\n" +
                        "    \"stageId\": 54,\n" +
                        "    \"stageIteration\": 1,\n" +
                        "    \"actionType\": \"Auto\",\n" +
                        "    \"wfeventId\": \"15545\",\n" +
                        "    \"nextActivityId\": \"366\"\n" +
                        "  }\n" +
                        "]";

                // Specify the request
                Response response = given().log().all()
                        .contentType("application/json")
                        .header("Authorization", "Bearer " + accessToken)  // Correctly formatted Authorization header
                        // .contentType("multipart/form-data")
                        .body(ReqBody)// Set Content-Type to multipart/form-data
                        //.multiPart("files", new File("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\data\\z.pdf"), "application/pdf")  // Attach PDF file as multipart with Content-Type as application/pdf
                        .when()
                        .post("/v1/ialtservice/generateAltTextNewVersionwmsSchedular")  // Ensure the endpoint is specified correctly; here it uses the baseURI
                        .then().log().all()
                        .statusCode(201)  // Expecting HTTP status code 201 Created
                        .extract()
                        .response();
            }


            String userId = response.jsonPath().getString("queueId");
            System.out.println("ALTstrings ID: " + userId);

            PDFstrings.add(userId);
            PDFstrings.add("Next--");
            System.out.println(ALTstrings);
            System.out.println(ALTstrings.size());

        }
    }








/*
public void createUser() {

    for(int i=0;i<1;i++)
    {
        mail="Gan@_123"+i+"viki";
        // System.out.println(mail);

        RestAssured.useRelaxedHTTPSValidation();

        RestAssured.baseURI = "https://quixl-test.integra.co.in";
        //RestAssured.port = 443;

        String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NTgwMjY3MDRkNTZjNjRlOTM4OGQyYzAiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjU5NjIzMzIsImV4cCI6MTcyNTk2NTkzMiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.vVNSxYVmiq9cTxMyKu_dedSyY4UrFxwkWy_cNjRWDQPdlYua1gh4inpvN-ZwwjDVM5wmHIBTQzuVbv3tFHE40WgfmHUs5PSDTgDvYDH0HGR1yf12hK7prF94-3GDhpApUD-yXY9Mt75GXInDIku7e0Mt2lCHbNX-y_ghcGJXaPQbua72Db3FoutgFH8c5PG-iJdM20AVMEleAsIl03mwBSih3w7-04kRCTmPM69CjtSdUhJIwqwTMD6PDeR5psex5TQLAGCPhfFe-3cW000mDffBx7D-uELoYpGe4_oqn7gbPwcjbXuW3fKwyqgvtS3Op7BgNa4ZBxBLfWDOYlri1A";
        String requestBody = "{\n" +
                "  \"tenant\": \"65b9d660ac32941d7845f413\",\n" +
                "  \"firstName\": \"Test\",\n" +
                "  \"lastName\": \"Demo\",\n" +
                "  \"email\": \"testdemo123@gmail.com\",\n" +
                "  \"role\": \"User\",\n" +
                "  \"allowedApps\": [],\n" +
                "  \"updatedBy\": \"64dde03bc684fd39b02353f0\",\n" +
                "  \"updatedOn\": \"2024-09-06T06:31:11.668Z\",\n" +
                "  \"password\": \""+mail+"\"\n" +
                "}";


        Response response = given().log().all()
                .contentType("application/json")
                .header("Authorization", "Bearer " + accessToken)
                .body(requestBody)
                .when()
                .patch("/v1/tenant/65b9d660ac32941d7845f413")
                .then().log().all()
                .statusCode(200) // Expecting HTTP status code 201 Created
                //.body("isActive", equalTo("true"))
                .extract()
                .response();

        // Optionally, extract the response ID or other data
        String userId = response.jsonPath().getString("id");
      //  System.out.println("User ID: " + userId);


        strings.add(userId);
        strings.add("Next--");
       // System.out.println(strings);
    }
}


 */




/*
    public void createUser() {

    for(int i=0;i<1000;i++)
    {
         mail="test"+i+"viki";
       // System.out.println(mail);

    RestAssured.useRelaxedHTTPSValidation();

    RestAssured.baseURI = "https://quixl-test.integra.co.in";
    //RestAssured.port = 443;

     String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NTgwMjY3MDRkNTZjNjRlOTM4OGQyYzAiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjU5NjIzMzIsImV4cCI6MTcyNTk2NTkzMiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.vVNSxYVmiq9cTxMyKu_dedSyY4UrFxwkWy_cNjRWDQPdlYua1gh4inpvN-ZwwjDVM5wmHIBTQzuVbv3tFHE40WgfmHUs5PSDTgDvYDH0HGR1yf12hK7prF94-3GDhpApUD-yXY9Mt75GXInDIku7e0Mt2lCHbNX-y_ghcGJXaPQbua72Db3FoutgFH8c5PG-iJdM20AVMEleAsIl03mwBSih3w7-04kRCTmPM69CjtSdUhJIwqwTMD6PDeR5psex5TQLAGCPhfFe-3cW000mDffBx7D-uELoYpGe4_oqn7gbPwcjbXuW3fKwyqgvtS3Op7BgNa4ZBxBLfWDOYlri1A";
        String requestBody = "{\n" +
                "  \"region\": \"India\",\n" +
                "  \"defaultLanguage\": \"English\",\n" +
                "  \"email\": \"testtenant@example.com\",\n" +
                "  \"phone\": \"7837483293\",\n" +
                "  \"tenantDescription\": \"descasd asdfsa asdfsda asdfsda asdfsadfsadfsadf asdf\",\n" +
                "  \"firstName\": \"Test11\",\n" +
                "  \"lastName\": \"Tenant\",\n" +
                "  \"tenantName\": \""+mail+"\"\n" +
                "}";


        Response response = given().log().all()
                .contentType("application/json")
                .header("Authorization", "Bearer " + accessToken)
                .body(requestBody)
                .when()
                .post("/v1/tenant/")
                .then().log().all()
                .statusCode(201) // Expecting HTTP status code 201 Created
                //.body("isActive", equalTo("true"))
                .extract()
                .response();

        // Optionally, extract the response ID or other data
        String userId = response.jsonPath().getString("id");
        System.out.println("User ID: " + userId);


    strings.add(userId);
    strings.add("Next--");
    System.out.println(strings);
    }
    }



    @Test
    public void deleteUser() {

            RestAssured.useRelaxedHTTPSValidation();

            RestAssured.baseURI = "https://quixl-test.integra.co.in";
            RestAssured.port = 443;

            String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NTgwMjY3MDRkNTZjNjRlOTM4OGQyYzAiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjU5NTE3MTYsImV4cCI6MTcyNTk1NTMxNiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.uKkG386vV4bR0jFPdyGrfMNAQC24vlCL_oWKmbSNVdLpL8_hRwbOKNdsVPVPdt5znsSEG4HhVhwnL8382aPrAf355pCub4JFBiWc4yhSWyqFa4rmNxToDUWzoNsF4CgYFCPfwp6v_V5stYIN_R-WAVLTf8qTmW_o2TJIWXv2BpYuMhWhYFpJyV1uYyDTn06k-_xALkiP_-O2SL707IfoJ5WapQRyj0eGr7zMjzFXaMNWL0ZZwZiGZhaXLDY1eCRw-QzfV1PUEIn4jlluyd7yNoQZ6tcIdrvc4q55xrJEAjgLz18sqTX6m7erVzGqQ9aFi944gA27RiA2qO3CAaScug";



            Response response = given().log().all()
                    .contentType("application/json")
                    .header("Authorization", "Bearer " + accessToken)
                   // .body(requestBody)
                    .when()
                    .delete("/v1/users/66dff8c2a67f29cacb20201b")
                    .then().log().all()
                  //  .statusCode(201) // Expecting HTTP status code 201 Created
                    //.body("isActive", equalTo("true"))
                    .extract()
                    .response();
            /*
            // Optionally, extract the response ID or other data
            String userId = response.jsonPath().getString("id");
            System.out.println("User ID: " + userId);


            strings.add(userId);
            strings.add("Next--");
            System.out.println(strings);


        }
         */

}
