package java1rest;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import page.LoginPage;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static io.restassured.RestAssured.given;

public class newupdate {

    ArrayList<String> list = new ArrayList<>();

    List<String> Emailid = Collections.synchronizedList(new ArrayList<>());
    List<String> Cuser = Collections.synchronizedList(new ArrayList<>());
    List<String> PDFstrings = Collections.synchronizedList(new ArrayList<>());
    List<String> CLFstrings = Collections.synchronizedList(new ArrayList<>());
    List<String> ALTstrings = Collections.synchronizedList(new ArrayList<>());
    String accessToken;
    String accessToken1;
    // Use ThreadLocal for thread-safe WebDriver instances
    private ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    @BeforeMethod
    public void setupWebDriver() {
        // Initialize a new WebDriver instance for each thread
        driver.set(new ChromeDriver());
        driver.get().manage().window().maximize();
    }

    @AfterMethod
    public void teardownWebDriver() {
        // Ensure the WebDriver is closed after each test method
        if (driver.get() != null) {
            driver.get().quit();
        }
        driver.remove();  // Remove the WebDriver instance from ThreadLocal
    }

    @Test(priority = 0)
    public void createuserquixl() {
        WebDriver webDriver = driver.get();  // Get the WebDriver instance for the current thread
        webDriver.get("https://quixl-test.integra.co.in/login/");

        LoginPage lp = new LoginPage(webDriver);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        lp.clicksubmit();
        lp.enterUserName("superadmin@integra.co.in");
        lp.enterPassword("Admin@123");
        lp.loginButton();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


        // wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        // waitForElementToBeVisible(webDriver, By.xpath("//button[@type='submit']"), 10);  // Replace with actual element locator

        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        String tokenm = (String) js.executeScript("return window.localStorage.getItem('accessToken');");
        System.out.println("Extracted Token: " + tokenm);

        accessToken1 = tokenm;

        for (int i = 0; i < 10; i++) {
            RestAssured.useRelaxedHTTPSValidation();
            RestAssured.baseURI = "https://quixl-test.integra.co.in";

            Response response = given().log().all()
                    .contentType("application/json")
                    .header("Authorization", "Bearer " + accessToken1)
                    .body("{\n" +
                            "  \"tenant\": \"6582b41405f8e82a20f56f4e\",\n" +
                            "  \"firstName\": \"viki\",\n" +
                            "  \"lastName\": \"test\",\n" +
                            "  \"email\": \"vikitestq28" + i + "@gmail.com\",\n" +
                            "  \"role\": \"Admin\",\n" +
                            "  \"allowedApps\": [],\n" +
                            "  \"updatedBy\": \"64dde03bc684fd39b02353f0\",\n" +
                            "  \"updatedOn\": \"2024-09-06T06:31:11.668Z\",\n" +
                            "  \"password\": \"Admin@123\"\n" +
                            "}") // JSON Body
                    .when()
                    .post("/v1/users")
                    .then().log().all()
                    .statusCode(201)
                    .extract().response();

            String userId = response.jsonPath().getString("id");
            Cuser.add(userId);
            String email = response.jsonPath().getString("email");
            Emailid.add(email);
            System.out.println("Emails: " + Emailid);
            System.out.println("User IDs: " + Cuser);
        }
    }

    @DataProvider(name = "emailDataProvider", parallel = true)
    public Object[][] dataProviderMethod() {
        List<Object[]> data = new ArrayList<>();
        for (String email : Emailid) {
            data.add(new Object[]{email});
        }
        return data.toArray(new Object[0][]);
    }

    @Test(priority = 1, dataProvider = "emailDataProvider")
    public void extractTokenIalt(String email) {
        WebDriver webDriver = driver.get();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }// Get the WebDriver instance for the current thread
        webDriver.get("https://aigateway-ialt-test.integra.co.in");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        LoginPage lp = new LoginPage(webDriver);
        lp.clicksubmit();
        lp.enterUserName(email);
        lp.enterPassword("Admin@123");
        lp.loginButton();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        //waitForElementToBeVisible(webDriver, By.xpath("//button[@type='submit']");  // Replace with actual element locator

        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        String token = (String) js.executeScript("return window.localStorage.getItem('accessToken');");
        System.out.println("Extracted Token: " + token);
        accessToken = token;

        driver.get().quit();


        testPdfUpload();
        getImageClassificationgroup();
        generateAltTextNewVersion();

    }

    // @Test(priority = 2, dependsOnMethods = {"extractTokenIalt"})
    public void testPdfUpload() {
        RestAssured.useRelaxedHTTPSValidation();
       // RestAssured.baseURI = "http://BCPINT-L043:3000/";

        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

        Response response = given().log().all()
                .header("Authorization", "Bearer " + accessToken)
                .contentType("multipart/form-data")
                .multiPart("files", new File("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\data\\z.pdf"), "application/pdf")
                .when()
                .post("/v1/ialtimage/ImagePDFExtraction")
                .then().log().all()
                .statusCode(201)
                .extract().response();

        String userId = response.jsonPath().getString("_id");
        System.out.println("PDFstrings ID: " + userId);
        list = new ArrayList<>(Arrays.asList(userId.split(",")));
        // PDFstrings.add(userId);
        PDFstrings = list;


        System.out.println("firstttttttt");
        System.out.println(PDFstrings.size());
        System.out.println(PDFstrings);

    }


    //  @Test(priority = 3,dependsOnMethods = {"testPdfUpload"})
    public void getImageClassificationgroup() {


        //  RestAssured.useRelaxedHTTPSValidation();

       // RestAssured.baseURI = "http://BCPINT-L043:3000/";
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";
        System.out.println("ffff");
        System.out.println(PDFstrings);
        for (String ImgID : PDFstrings) {

            // Remove leading and trailing spaces using trim()
            String trimmedInput = ImgID.trim();

            String result = trimmedInput.replaceAll("[\\[\\]]", "");

            System.out.println(result);

            String ReqBody = "[{\"id\":\"" + result + "\"}]";

            Response response = given().log().all()
                    .contentType("application/json")
                    .header("Authorization", "Bearer " + accessToken)  // Correctly formatted Authorization header
                    .body(ReqBody)// Set Content-Type to multipart/form-data
                    .when()
                    .post("/v1/ialtservice/getImageClassificationgroup")  // Ensure the endpoint is specified correctly; here it uses the baseURI
                    .then().log().all()
                    .statusCode(200)  // Expecting HTTP status code 201 Created
                    .extract()
                    .response();


            String ClarificationID = response.jsonPath().getString("_id");
            System.out.println("CLFstrings ID: " + ClarificationID);

            CLFstrings.add(ClarificationID);

            System.out.println(CLFstrings);
            System.out.println(CLFstrings.size());
        }


    }


    // @Test(priority = 4,dependsOnMethods = {"getImageClassificationgroup"})

    public void generateAltTextNewVersion() {

        for (int i = 1; i <= 1; i++) {


            RestAssured.useRelaxedHTTPSValidation();

           // RestAssured.baseURI = "http://BCPINT-L043:3000/";
            RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

           // String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NWIyNTU5YTAxN2E0ZjQ2YmJjOTY4NjkiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjYyMTAwMjEsImV4cCI6MTcyNjIxMzYyMSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.mEGvuEF_x55uhrh2Hw8u_5_SlnDY3kBisCpWi50n9-YsX-CD2DaFiFQ0B_CEo-VEz9y33XIKt_DnGayC6bhKTboMcJYSJnx8g5KuBlrLHZOGnDP_iAOuwGTolky4CLFRerpu4okH_NM4Aqjj6s4tmpkfvURWqhAQNtFTyR5Mej-tntMl137uCFD4JEWPOrOMBU2xaNH65J5_1YNBpY97J5Sxz3DjBNpmjKIHhB4XyuTG0YEyixboX2jGFBIWBjaoTw9t8HFe6R2gFPvIVA6UZbRFj1JOUAm1Lh1BWgBbZKZ5c5AcG7aDw3ipHpLJaEdQo988VCPsSEkOAkB41xQHLA";
            for (String ImgID : CLFstrings) {
                System.out.println(ImgID);
                List<String> strings = new ArrayList<>();
                String ReqBody = "[\n" +
                        "  {\n" +
                        "    \"id\": \"" + ImgID + "\",\n" +
                        "    \"duId\": \"94\",\n" +
                        "    \"customerId\": \"14\",\n" +
                        "    \"wfId\": 38,\n" +
                        "    \"userId\": \"IS8433\",\n" +
                        "    \"bookid\": 157,\n" +
                        "    \"workorderId\": \"2971\",\n" +
                        "    \"serviceId\": \"1\",\n" +
                        "    \"stageId\": 54,\n" +
                        "    \"stageIteration\": 1,\n" +
                        "    \"actionType\": \"Auto\",\n" +
                        "    \"wfeventId\": \"15545\",\n" +
                        "    \"nextActivityId\": \"366\"\n" +
                        "  }\n" +
                        "]";
                Response response = given().log().all()
                        .contentType("application/json")
                        .header("Authorization", "Bearer " + accessToken)

                        .body(ReqBody)
                        .when()
                        .post("/v1/ialtservice/generateAltTextNewVersionwmsSchedular")
                        .then().log().all()
                        .statusCode(201)
                        .extract()
                        .response();


                String userId = response.jsonPath().getString("queueId");
                System.out.println("ALTstrings ID: " + userId);

                ALTstrings.add(userId);

                System.out.println(ALTstrings);


            }
            System.out.println(ALTstrings.size());
        }

        System.out.println("Lastttttttt");
        System.out.println(ALTstrings.size());
    }
}





