package java1rest;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;


public class TestSetup {
    static {
        RestAssured.baseURI = "https://quixl-test.integra.co.in";
       RestAssured.port = 443;
    }
}