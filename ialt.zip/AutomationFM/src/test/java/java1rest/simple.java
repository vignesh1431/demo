import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static io.restassured.RestAssured.given;

public class simple {

    ArrayList<String> list= new ArrayList<>();

    private List<String> PDFstrings = Collections.synchronizedList(new ArrayList<>());
    private List<String> CLFstrings = Collections.synchronizedList(new ArrayList<>());
    private List<String> ALTstrings = Collections.synchronizedList(new ArrayList<>());
    private final String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9";

    @Test(invocationCount = 50, threadPoolSize = 100, priority = 2)
    public void testPdfUpload() {
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

        Response response = given().log().all()
                .header("Authorization", "Bearer " + accessToken)
                .contentType("multipart/form-data")
                .multiPart("files", new File("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\data\\1img.docx"),"application/msword")
                .when()
                .post("/v1/ialtimage/ImagePDFExtraction")
                .then().log().all()
                .statusCode(201)
                .extract()
                .response();

        String userId = response.jsonPath().getString("_id");
        System.out.println("PDFstrings ID: " + userId);
        list = new ArrayList<>(Arrays.asList(userId.split(",")));
        // PDFstrings.add(userId);
        PDFstrings = list;
        synchronized (PDFstrings) {
            PDFstrings.add(userId);
        }

        System.out.println("PDFstrings: " + PDFstrings);
        System.out.println("PDFstringsfirt: " + PDFstrings.size());

        // Call dependent methods after uploading
        getImageClassificationgroup();
        generateAltTextNewVersion();

        System.out.println("PDFstringsfirt:over  " + PDFstrings.size());
    }

    private void getImageClassificationgroup() {
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

        synchronized (PDFstrings) {
            for (String ImgID : PDFstrings) {
                String trimmedInput = ImgID.trim();
                String result = trimmedInput.replaceAll("[\\[\\]]", "");

                String reqBody = "[{\"id\":\"" + result + "\"}]";

                Response response = given().log().all()
                        .contentType("application/json")
                        .header("Authorization", "Bearer " + accessToken)
                        .body(reqBody)
                        .when()
                        .post("/v1/ialtservice/getImageClassificationgroup")
                        .then().log().all()
                        .statusCode(200)
                        .extract()
                        .response();

                String clarificationID = response.jsonPath().getString("_id");
                System.out.println("CLFstrings ID: " + clarificationID);
                synchronized (CLFstrings) {
                    CLFstrings.add(clarificationID);
                }

                System.out.println("CLFstrings: " + CLFstrings);
                System.out.println("CLFstringsmid: " + CLFstrings.size());

            }
        }
    }

    private void generateAltTextNewVersion() {
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in";

        synchronized (CLFstrings) {

            for (String ImgID : CLFstrings) {

                if (ImgID == "" || ImgID.trim().isEmpty()) {
                    break;  // Skip processing if the string is null or empty
                }

                String result = ImgID.trim().replaceAll("[\\[\\]]", "");



                String reqBody = "[\n" +
                        "  {\n" +
                        "    \"id\": \"" + result + "\",\n" +
                        "    \"duId\": \"94\",\n" +
                        "    \"customerId\": \"14\",\n" +
                        "    \"wfId\": 38,\n" +
                        "    \"userId\": \"IS8433\",\n" +
                        "    \"bookid\": 157,\n" +
                        "    \"workorderId\": \"2971\",\n" +
                        "    \"serviceId\": \"1\",\n" +
                        "    \"stageId\": 54,\n" +
                        "    \"stageIteration\": 1,\n" +
                        "    \"actionType\": \"Auto\",\n" +
                        "    \"wfeventId\": \"15545\",\n" +
                        "    \"nextActivityId\": \"366\"\n" +
                        "  }\n" +
                        "]";

                Response response = given().log().all()
                        .contentType("application/json")
                        .header("Authorization", "Bearer " + accessToken)
                        .body(reqBody)
                        .when()
                        .post("/v1/ialtservice/generateAltTextNewVersionwmsSchedular")
                        .then().log().all()
                       // .statusCode(201)
                        .extract()
                        .response();

                String altTextId = response.jsonPath().getString("queueId");
                System.out.println("ALTstrings ID: " + altTextId);
                synchronized (ALTstrings) {
                    ALTstrings.add(altTextId);
                }

                System.out.println("ALTstrings: " + ALTstrings);

                System.out.println("ALTstringslast: " + ALTstrings.size());
            }
        }
    }
}
