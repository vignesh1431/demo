package java1rest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Test;
import java.io.File;

import static org.hamcrest.Matchers.*;

public class ImageExtractionPDFAPI {

    @Test
    public void testImageExtractionFromPdf() {

        String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlQTlEM3l6ek9NVFlMWS1xTGh2NiJ9.eyJpc3MiOiJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2NWIyNTU5YTAxN2E0ZjQ2YmJjOTY4NjkiLCJhdWQiOlsiYWlnYXRld2F5LmludGVncmEuY28uaW4iLCJodHRwczovL2Rldi10NDEwamFlN3Frb29yenZyLnVzLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE3MjYxNDM0NjYsImV4cCI6MTcyNjE0NzA2Niwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImF6cCI6IkVqMk1aSkt5aWJ6MVIyc0djd3lqUHJRbERNRG82cDFmIiwicGVybWlzc2lvbnMiOltdfQ.HAroOY7kjGhIp1ZetQZv8QsHQo1KlPGqpTA8yyd3abzis3VBFSptrjMAiYDWO_Ft7eAkkvvck2nBvNzzpZfKMOA3B2C0GxK77XlWqVUdiN-F0EvVzZMeWUxiDRqNNlPYqzETPQP9yZkXGoiFLJ0PxjeFfhg_YMD763sAXXnMSBt8djnaoTD99qyMA054M2wXWUXtThbF3CvCeR5LliQe7a4Y67uKTaRPAHfV4-XgT32Kt0WaH6IQVsA65xz2rX2CSphcF3h1_d7LETE3PA2Mv8mzyTSRZMb05-q8yLtNQ2moTDisYy8a2tjLh4BSefXtKu96iL2Xj_GKCaPK6uBMZg";
        // Set the base URL for the API
        RestAssured.baseURI = "https://aigateway-ialt-test.integra.co.in/v1/ialtimage/ImagePDFExtraction"; // Example API endpoint

        // Specify the request
        RequestSpecification request = RestAssured.given();

        // Add headers
        request.header("Authorization", "Bearer"+ accessToken); // Replace with your API key
        request.header("Content-Type", "multipart/form-data");

        // Add PDF file to the request
        request.multiPart("file", new File("src/test/resources/data/z.pdf")); // Path to your local PDF file

        // Add other form data if necessary
      //  request.multiPart("pages", "1-2"); // Specify the pages to extract images from

        // Send POST request and get the response
        Response response = request.post();

        // Validate the response
        response.then().statusCode(200);
        response.then().body("status", equalTo("success"));

        // Extract the response body and print it (if needed)
        String responseBody = response.getBody().asString();
        System.out.println("Response Body is: " + responseBody);

        // Additional assertions based on the response content can be added here
    }
}
