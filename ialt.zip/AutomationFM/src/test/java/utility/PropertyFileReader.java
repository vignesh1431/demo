package utility;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyFileReader {

static	FileInputStream fis;
	static Properties pro;
	
	public static String getLocator(String key)
	{
		
		try {
			fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\config\\config.properties");
			pro= new Properties();
			pro.load(fis);
			return pro.getProperty(key);
		
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


}
