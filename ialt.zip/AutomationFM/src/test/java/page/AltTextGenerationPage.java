package page;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import java.awt.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
public class AltTextGenerationPage {
    WebDriver driver;
    public AltTextGenerationPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this);
    }
    @FindBy(xpath="//p[normalize-space(text())='Alt Text Generation']")
    private WebElement AltTextGenerationBtn;

    //@FindBy(xpath="//p[text()=\"Drag and drop\"]")
    @FindBy(xpath = "//input[@type=\"file\"]/following-sibling::p[text()=\"Drag and drop\"]")
    private WebElement browseButton;

    public void clickOnAltTextGeneration() throws InterruptedException {
        //driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);

        WebElement element =AltTextGenerationBtn;
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(2000); // Wait before retrying
            }
        }


       // AltTextGenerationBtn.click();
        //driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
       // Thread.sleep(5000);

    }

    public void uploadFile(String name) throws AWTException
    {
        String fname=System.getProperty("user.dir")+"\\src\\test\\resources\\data\\"+name;


        WebElement uploadElement = driver.findElement(By.xpath("//div[@class=\"uploadIalt\"]//input[@type=\"file\"]")); // Adjust the locator as needed
        uploadElement.sendKeys(fname);


        // WebElement submitButton = driver.findElement(By.id("submitButton")); // Adjust the locator as needed
        // submitButton.click();

/*
        StringSelection stringSelection = new StringSelection(fname);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
        Robot robot1 = new Robot();
        robot1.keyPress(KeyEvent.VK_CONTROL);

        robot1.keyPress(KeyEvent.VK_V);
       // robot1.setAutoDelay(3000);
        robot1.keyRelease(KeyEvent.VK_V);
        robot1.keyRelease(KeyEvent.VK_CONTROL);
    //    robot1.setAutoDelay(3000);
        robot1.keyPress(KeyEvent.VK_ENTER);
     //   robot.setAutoDelay(3000);
     //   robot.keyRelease(KeyEvent.VK_ENTER);
     //   robot.setAutoDelay(3000);
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
    */
    }


    public void selectProject() throws InterruptedException
    {
        /*
        Thread.sleep(3000);

        driver.findElement(By.xpath("//div[normalize-space(text())='Select project']")).click();

        java.util.List<WebElement> project =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        for(WebElement c:project)
        {
            String name=	c.getAttribute("data-value");
            Thread.sleep(200);
            if(name.contains("Sage"))
            {
                c.click();
                break;
            }
        }
        Thread.sleep(2000);
    */

        WebElement element = driver.findElement(By.xpath("//div[normalize-space(text())='Select Project']"));
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(5000); // Wait before retrying
            }
        }

        List<WebElement> client =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        Thread.sleep(200);
        for(WebElement c:client)
        {
            String name=	c.getAttribute("data-value");
            System.out.println(name);
            Thread.sleep(200);
            if(name.contains("Sage"))
            {
                c.click();
                break;
            }
        }
    }


    public void selectClient() throws InterruptedException
    {
        Thread.sleep(5000);
        WebElement element1 = driver.findElement(By.xpath("//span[@aria-label='Select Image'][1]"));

        WebElement element = driver.findElement(By.xpath("//div[normalize-space(text())='Select client']"));
        int retries = 0;
        while (retries < 1000) {
            try {
                element1.click();
                Thread.sleep(2000);
                //element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(500); // Wait before retrying
            }
        }
        int retries1 = 0;
        while (retries1 < 1000) {
            try {
               // element1.click();
                Thread.sleep(2000);
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries1++;
                Thread.sleep(500); // Wait before retrying
            }
        }

        List<WebElement> client =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        Thread.sleep(200);
        for(WebElement c:client)
        {
            String name=	c.getAttribute("data-value");
            System.out.println(name);
            Thread.sleep(200);
            if(name.contains("HAP"))
            {
                c.click();
                break;
            }
        }
    }


    public void selectAssert() throws InterruptedException
    {
        WebElement element = driver.findElement(By.xpath("//select[contains(.,'Select AssetSelect AssetChemical EquationChemical StructureCircuitArea graphBar GraphBox PlotBubble ChartGraphHeat MapHistogramLine GraphMulti line GraphMultiple graphNormal/Bell CurvePie ChartRadar GraphScatter plotTrend line graphWaterfall GraphCash Flow Diagramcontinuum diagramCyclic diagramFlowchartInfographicsInfographicsVenn diagramMapMath EquationAnatomical structureBiologyLabelled diagramNon TextualNon-Textual IllustrationNon-Textual PhotographScreenshotsTableTextual IllustrationTextual OCR')]"));
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(5000); // Wait before retrying
            }
        }

        Select select = new Select(element);

        // Select an option by visible text
        select.selectByVisibleText("Circuit");

        /*
        System.out.println(element);
        List<WebElement> client =driver.findElements(By.xpath("//li[@role='menuitem']"));
        Thread.sleep(200);
        for(WebElement c:client)
        {
            String name=	c.getAttribute("value");
            System.out.println(name);
            Thread.sleep(200);
            if(name.contains("Circuit"))
            {
                c.click();
                break;
            }
        }

         */
    }



    public void clickSaveAndNext()
    {
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[text()='Save & Next']")).click();
    }


    public void clickNext() throws InterruptedException {

        Thread.sleep(6000);
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);


        WebElement element = driver.findElement(By.xpath("//button[text()='Next']"));
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(2000); // Wait before retrying
            }
        }

}

    public void clickGenerateAltText() throws InterruptedException {


        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);


        WebElement element = driver.findElement(By.xpath("//button[@aria-label='Generate AltText']"));
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(2000); // Wait before retrying
            }
        }

    }
}

