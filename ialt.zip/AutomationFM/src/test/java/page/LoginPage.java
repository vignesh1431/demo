package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
WebDriver driver;
	
	public LoginPage(WebDriver d)
	{
		this.driver=d;
		
	}
	public void clicksubmit()
	{
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
	public void enterUserName(String name)
	{
		driver.findElement(By.id("email")).sendKeys(name);	
	}
	
	public void enterPassword(String pwd)
	{
		//driver.get(pro.getProperty("passwordValue"));
		driver.findElement(By.id("password")).sendKeys(pwd);
		
	}
	public void loginButton()
	{
		driver.findElement(By.id("btn-login")).click();	
	}

}
