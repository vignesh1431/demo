package page;
import page.AltTextGenerationPage;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ImageClassificationPage  {
    WebDriver driver;
    public ImageClassificationPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this);
    }
    @FindBy(xpath="//div//p[text()=\"Image Classification\"]")
    private WebElement ImgClassificationBtn;

    //@FindBy(xpath="//p[text()=\"Drag and drop\"]")
    @FindBy(xpath = "//input[@type=\"file\"]/following-sibling::p[text()=\"Drag and drop\"]")
    private WebElement browseButton;

    public void clickOnImageClassification() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        ImgClassificationBtn.click();
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        Thread.sleep(5000);
        //browseButton.click();
        //Thread.sleep(5000);
        //WebElement fileInput =
        //        driver.findElement(By.xpath("//div[@class=\"uploadIalt\"]")).sendKeys("sample-img");
//        fileInput.click();
//        fileInput.sendKeys("sample-img");
    }

    public void uploadFile(String name) throws AWTException
    {
        String fname=System.getProperty("user.dir")+"\\src\\test\\resources\\data\\"+name;


        WebElement uploadElement = driver.findElement(By.xpath("//div[@class=\"uploadIalt\"]//input[@type=\"file\"]")); // Adjust the locator as needed
        uploadElement.sendKeys(fname);


       // WebElement submitButton = driver.findElement(By.id("submitButton")); // Adjust the locator as needed
       // submitButton.click();

/*
        StringSelection stringSelection = new StringSelection(fname);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
        Robot robot1 = new Robot();
        robot1.keyPress(KeyEvent.VK_CONTROL);

        robot1.keyPress(KeyEvent.VK_V);
       // robot1.setAutoDelay(3000);
        robot1.keyRelease(KeyEvent.VK_V);
        robot1.keyRelease(KeyEvent.VK_CONTROL);
    //    robot1.setAutoDelay(3000);
        robot1.keyPress(KeyEvent.VK_ENTER);
     //   robot.setAutoDelay(3000);
     //   robot.keyRelease(KeyEvent.VK_ENTER);
     //   robot.setAutoDelay(3000);
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
    */
    }


    public void selectProject() throws InterruptedException
    {
        Thread.sleep(200);

        driver.findElement(By.xpath("//div[normalize-space(text())='Select project']")).click();

        java.util.List<WebElement> project =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        for(WebElement c:project)
        {
            String name=	c.getAttribute("data-value");
            Thread.sleep(200);
            if(name.contains("Sage"))
            {
                c.click();
                break;
            }
        }
        Thread.sleep(200);
    }

    public void selectClient() throws InterruptedException
    {
        WebElement element = driver.findElement(By.xpath("//div[normalize-space(text())='Select client']"));
        int retries = 0;
        while (retries < 10000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(5000); // Wait before retrying
            }
        }

        List<WebElement> client =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        Thread.sleep(200);
        for(WebElement c:client)
        {
            String name=	c.getAttribute("data-value");
            System.out.println(name);
            Thread.sleep(200);
            if(name.contains("HAP"))
            {
                c.click();
                break;
            }
        }
    }

    public void clickSaveAndNext()
    {
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[text()='Save & Next']")).click();
    }



}
