package testSuites;

import base.TestBase;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testng.annotations.Test;
import page.AltTextGenerationPage;
import page.ImageExtractionPage;
import page.LoginPage;
import page.ReportsPage;

import org.junit.jupiter.api.condition.EnabledIf;
import org.junit.jupiter.api.condition.DisabledIf;

import java.awt.*;

public class ImageExtrctionTest extends TestBase {
	int count;

	@Test(priority = 1)
	public void login() {
		LoginPage lp = new LoginPage(driver);
		lp.clicksubmit();
//		 lp.enterUserName("ialtadmin@integra.co.in");
//		 lp.enterPassword("Admin@123");
		lp.enterUserName(pro.getProperty("UserNameValue"));
		lp.enterPassword(pro.getProperty("passwordValue"));
		lp.loginButton();
	}

	@Test(priority = 2)
	public void uploadImage() throws InterruptedException, AWTException {
		ImageExtractionPage ie = new ImageExtractionPage(driver);

		ie.clickImageExtraction();
		ie.clickBrowseButton();
		String fname = pro.getProperty("PDFname");
		ie.uploadFile(fname);
	}

	@Test(priority = 3)
	public void processImage() throws InterruptedException {
		ImageExtractionPage ie = new ImageExtractionPage(driver);
		ie.clickGetImages();
		ie.getImageCount();
		test.log(Status.FAIL,"image coun");

		count = ie.clickImageClasification();

		if (count < 50) {

			// ImageExtractionPage ie = new ImageExtractionPage(driver);
			ie.selectClient();
			ie.selectProject();
			ie.clickSaveAndNext();
			AltTextGenerationPage al = new AltTextGenerationPage(driver);

			al.clickNext();
			al.clickGenerateAltText();
			ReportsPage rp = new ReportsPage(driver);
			rp.clickOnReports();


		} else {

			System.out.println("Moved to Quemanagement");

		}
	}

	/*
@Test(priority=4)
public void selectSave() throws InterruptedException
{
	ImageExtractionPage ie = new ImageExtractionPage(driver);
	ie.selectClient();
	ie.selectProject();
	ie.clickSaveAndNext();


	AltTextGenerationPage al = new AltTextGenerationPage(driver);

	al.clickNext();
	al.clickGenerateAltText();
	ReportsPage rp= new ReportsPage(driver);
	rp.clickOnReports();



}


	 */
/*

	private static int ImageCount;

	private static boolean isConditionMet() {
		return (ImageCount < 50); //this line should return true or false
    }
	@Test(dependsOnMethods ="processImage()")
	@EnabledIf("isConditionMet")
	void testConditionallyEnabled(){
		System.out.println("condition matched");
	}
	@Test
	@EnabledIf("isConditionMet")
	void testConditionallyDisabled(){
		System.out.println("condition not matched. Test skipped");
	}
*/


}
