package testSuites;

import base.TestBase;
import io.cucumber.java.bs.I;
import org.testng.annotations.Test;
import page.AltTextGenerationPage;
import page.ImageClassificationPage;
import page.LoginPage;
import page.ReportsPage;



import java.awt.*;
import java.io.IOException;

public class ImageClassificationTest extends TestBase {
    @Test(priority=1)
    public void login()
    {

        LoginPage lp = new LoginPage(driver);
        lp.clicksubmit();
        lp.enterUserName(pro.getProperty("UserNameValue"));
        lp.enterPassword(pro.getProperty("passwordValue"));
        lp.loginButton();
    }
    @Test(priority=2)
    public void imageClassification() throws AWTException, InterruptedException, IOException {
        ImageClassificationPage ic = new ImageClassificationPage(driver);
        ic.clickOnImageClassification();
        getScreenshot("ss");
        ic.uploadFile("sample-img.jpg");
    }
        @Test(priority=3)
        public void selectandSave() throws InterruptedException {
            ImageClassificationPage ic = new ImageClassificationPage(driver);
            ic.selectClient();
            ic.selectProject();
            ic.clickSaveAndNext();
        }

    @Test(priority=4)
    public void Reportsclick() throws InterruptedException {
            AltTextGenerationPage al = new AltTextGenerationPage(driver);
        //  al.clickOnAltTextGeneration();

            al.clickNext();
            al.clickGenerateAltText();
            ReportsPage rp= new ReportsPage(driver);
            rp.clickOnReports();

        }







    }

