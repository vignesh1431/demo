package testSuites;

import base.TestBase;
import org.testng.annotations.Test;
import page.LoginPage;

public class LoginTest extends TestBase{
	@Test
	public void login()
	{
		LoginPage lp = new LoginPage(driver);
		lp.clicksubmit();
		lp.enterUserName(pro.getProperty("UserNameValue"));
		lp.enterPassword(pro.getProperty("passwordValue"));
		lp.loginButton();
	}

}
